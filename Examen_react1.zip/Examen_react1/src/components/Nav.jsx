import React from 'react'
import { Link } from 'react-router-dom'

const Nav = () => {
  return (
    <>
      <nav className='bg-purple-300'>
          <ul className='flex gap-4'>
              <Link to="/">Home</Link>
              <Link to="/contacto">Contacto</Link>
              <Link to="/categorias/Clothes">Clothes</Link>
              <Link to="/categorias/Electronics">Electronics</Link>
              
          </ul>
        </nav>
    </>
  )
}

export default Nav