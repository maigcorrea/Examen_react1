import React from 'react'

const Cards = ({productos,palabraBusc,categoria,mostrarDetalles}) => {
  return (
    <>
            {productos?.map(producto=>(
                producto.category.name.includes(categoria) || categoria==null ?
                producto.title.toLowerCase().includes(palabraBusc) || palabraBusc==null ?
                <div className='border text-center' key={producto.id}>
                    <img src={producto.images} alt="" className='w-[200px] mx-auto'/>
                    <h3>{producto.title}</h3>
                    <p>{producto.price}</p>
                    <button onClick={() => mostrarDetalles(producto)}>Ver más</button>
                </div>:null
                :null
            ))}
    </>
  )
}

export default Cards