import React from 'react'

const Buscador = ({cambiar}) => {
  return (
    <>
        <div className="flex justify-center my-[50px]">
            <input type="search" className='border' onChange={(e) =>{cambiar(e.target.value)}} />
        </div>
    </>
  )
}

export default Buscador