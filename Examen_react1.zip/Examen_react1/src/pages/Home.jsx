import React, { useEffect, useState } from 'react'
import Cards from '../components/Cards'
import Buscador from '../components/Buscador'
import Detalles from '../components/Detalles'

const Home = () => {

  const [productos, setProductos] = useState([])
  useEffect(() => {
    fetch("https://api.escuelajs.co/api/v1/products")
    .then(respuesta => respuesta.json())
    .then(datos => setProductos(datos))
  }, [])

  const [busqueda, setBusqueda] = useState("")
  let obtenerPalabra = (palabra) =>{
    setBusqueda(palabra)
  }

  const [detalles, setDetalles] = useState()
  let verDetalles = (details) =>{
    setDetalles(details)
  }


  
  return (
    <>
      <Buscador cambiar={(pal) => obtenerPalabra(pal)}></Buscador>
      <section className='grid grid-cols-4'>
        <Cards productos={productos} palabraBusc={busqueda} mostrarDetalles={(details) => verDetalles(details)}></Cards>
      </section>
      <div className="">
        {detalles !=null ? <Detalles details={detalles}></Detalles> :null}
      </div>
    </>
  )
}

export default Home