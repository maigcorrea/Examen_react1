import React from 'react'

const Contacto = () => {
  return (
    <>
        <form action="#" className='bg-amber-500'>
            <label htmlFor="nom">Nombre:</label>
            <input type="text" />
            <label htmlFor="email">Email:</label>
            <input type="email" name="email" id="" />
            <label htmlFor="msj">Mensaje:</label>
            <input type="text" name="msj" id="" />

            <input type="submit" value="Enviar" />
        </form>
    </>
  )
}

export default Contacto