import React from 'react'

const Detalles = ({details}) => {
  return (
    <>
        <div className="">
            <img src={details.images} alt="" />
            <h2>{details.title}</h2>
        </div>
    </>
  )
}

export default Detalles