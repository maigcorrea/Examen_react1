import React from 'react'
import Nav from '../components/Nav'

const header = () => {
  return (
    <>
      <Nav></Nav>
    </>
  )
}

export default header