import { useState } from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Home from './pages/Home'
import Plantilla from './layout/Plantilla'
import Contacto from './pages/Contacto'
import Categorias from './pages/Categoria'


function App() {

  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Plantilla></Plantilla>}>
            <Route index element={<Home></Home>}></Route>
            <Route path='/contacto' element={<Contacto></Contacto>}></Route>
            <Route path='/categorias/:categoria' element={<Categorias></Categorias>}></Route>
          </Route>
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
